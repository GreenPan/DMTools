# DND5e classpack for fvtt

整合了大部分种族，职业，物品，法术，同时可以使dm完全关闭babele换取加载性能。

使用方法：  
打开安装MOD界面，复制以下路径

    https://github.com/HJSmile/classpack/releases/latest/download/module.json

粘贴至以下位置后，点击安装

![MODPanel](./image/MODPanel.png)
